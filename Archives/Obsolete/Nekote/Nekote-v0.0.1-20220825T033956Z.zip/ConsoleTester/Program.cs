﻿using System.Diagnostics;
using System.Reflection;
using Nekote;

namespace ConsoleTester
{
    internal class Program
    {
        static void Main (string [] args)
        {
        }
    }
}
