using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace fanApiJwt.Controllers
{
    [ApiController]
    [Route ("user")]
    public class UserController: ControllerBase
    {
        private readonly IConfiguration mConfiguration;

        private readonly ILogger <UserController> mLogger;

        private readonly ApplicationDbContext mDbContext;

        private readonly UserManager <ApplicationUser> mUserManager;

        private readonly SignInManager <ApplicationUser> mSignInManager;

        private readonly AmazonSimpleEmailServiceWrapper mAmazonSimpleEmailServiceWrapper;

        private readonly AmazonSimpleNotificationServiceWrapper mAmazonSimpleNotificationServiceWrapper;

        public UserController (IConfiguration configuration, ILogger <UserController> logger, ApplicationDbContext dbContext,
            UserManager <ApplicationUser> userManager, SignInManager <ApplicationUser> signInManager,
            AmazonSimpleEmailServiceWrapper amazonSimpleEmailServiceWrapper, AmazonSimpleNotificationServiceWrapper amazonSimpleNotificationServiceWrapper)
        {
            mConfiguration = configuration;
            mLogger = logger;
            mDbContext = dbContext;
            mUserManager = userManager;
            mSignInManager = signInManager;
            mAmazonSimpleEmailServiceWrapper = amazonSimpleEmailServiceWrapper;
            mAmazonSimpleNotificationServiceWrapper = amazonSimpleNotificationServiceWrapper;
        }

        [HttpGet ("send-email")]
        public async Task <IActionResult> SendEmail ()
        {
            var xResponse = await mAmazonSimpleEmailServiceWrapper.SendEmailAsync
            (
                senderAddress: mConfiguration ["Aws:SenderAddress"]!,
                toAddresses: new [] { mConfiguration ["Aws:ToAddress"]! },
                ccAddresses: Enumerable.Empty <string> (),
                bccAddresses: Enumerable.Empty <string> (),
                subject: "Test Email",
                htmlBody: "Html<br />body.",
                textBody: $"Text{Environment.NewLine}body."
            );

            if (xResponse.HttpStatusCode == HttpStatusCode.OK)
            {
                string xMessage = $"Email '{xResponse.MessageId}' sent.";
                mLogger.LogInformation (xMessage);
                return Ok (new { Message = xMessage });
            }

            else
            {
                string? xMessage = xResponse.ToString ();
                mLogger.LogError (xMessage);
                return BadRequest (new { Message = xMessage });
            }
        }

        [HttpGet ("send-sms")]
        public async Task <IActionResult> SendSms ()
        {
            var xResponse = await mAmazonSimpleNotificationServiceWrapper.PublishAsync
            (
                phoneNumber: mConfiguration ["Aws:PhoneNumber"]!,
                message: "Test SMS"
            );

            if (xResponse.HttpStatusCode == HttpStatusCode.OK)
            {
                string xMessage = $"SMS '{xResponse.MessageId}' sent.";
                mLogger.LogInformation (xMessage);
                return Ok (new { Message = xMessage });
            }

            else
            {
                string? xMessage = xResponse.ToString ();
                mLogger.LogError (xMessage);
                return BadRequest (new { Message = xMessage });
            }
        }

        private string iGenerateJwtToken (ApplicationUser user)
        {
            var xTokenHandler = new JwtSecurityTokenHandler ();
            var xKey = Encoding.ASCII.GetBytes (mConfiguration ["Jwt:Key"]!);

            var xTokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity (new[] { new Claim ("id", user.Id) }),
                Expires = DateTime.UtcNow.AddHours (1),
                SigningCredentials = new SigningCredentials (new SymmetricSecurityKey (xKey), SecurityAlgorithms.HmacSha256Signature)
            };

            var xToken = xTokenHandler.CreateToken (xTokenDescriptor);
            return xTokenHandler.WriteToken (xToken);
        }

        [HttpPost ("register")]
        public async Task <IActionResult> Register ([FromBody] RegisterModel model)
        {
            var xUser = new ApplicationUser
            {
                CreationUtc = DateTime.UtcNow,
                IsActive = true,
                IsDeleted = false,

                UserName = model.Email,
                Email = model.Email
            };

            var xResult = await mUserManager.CreateAsync (xUser, model.Password);

            if (xResult.Succeeded)
                return Ok (new { Token = iGenerateJwtToken (xUser) });

            return BadRequest (xResult.Errors);
        }

        [HttpPost ("login")]
        public async Task <IActionResult> Login ([FromBody] LoginModel model)
        {
            var xAttempt = new LoginAttempt
            {
                Id = Guid.NewGuid (),
                UserName = model.Email,
                AttemptUtc = DateTime.UtcNow,
                IsSuccessful = false,
                IpAddress = Request.HttpContext.Connection.RemoteIpAddress?.ToString (),
                UserAgent = Shared.GetStringOrNull (Request.Headers ["User-Agent"]),
                Referrer = Shared.GetStringOrNull (Request.Headers ["Referer"])
            };

            try
            {
                var xUser = await mUserManager.FindByEmailAsync (model.Email);

                if (xUser != null)
                {
                    if (xUser.IsActive == false)
                        return BadRequest (new { Message = "User account not active." });

                    if (xUser.IsDeleted == false)
                    {
                        var xResult = await mSignInManager.PasswordSignInAsync (model.Email, model.Password, isPersistent: false, lockoutOnFailure: true);

                        if (xResult.Succeeded)
                        {
                            xAttempt.IsSuccessful = true;
                            xUser.LastLoginUtc = DateTime.UtcNow;
                            await mUserManager.UpdateAsync (xUser);
                            return Ok (new { Token = iGenerateJwtToken (xUser!) });
                        }

                        else if (xResult.IsNotAllowed)
                            return BadRequest (new { Message = "User account not allowed." });

                        else if (xResult.IsLockedOut)
                            return BadRequest (new { Message = "User account locked out." });
                    }
                }

                return Unauthorized ();
            }

            finally
            {
                mDbContext.LoginAttempts.Add (xAttempt);
                await mDbContext.SaveChangesAsync ();

                mLogger.LogInformation ($"Login attempt by '{model.Email}' was {(xAttempt.IsSuccessful ? "successful" : "unsuccessful")}.");
            }
        }
    }
}
