﻿using Microsoft.AspNetCore.Identity;

namespace fanApiJwt
{
    public class ApplicationUser: IdentityUser
    {
        public required DateTime CreationUtc { get; set; }

        public DateTime? LastLoginUtc { get; set; }

        public required bool IsActive { get; set; }

        public DateTime? DeactivationUtc { get; set; }

        public required bool IsDeleted { get; set; }

        public DateTime? DeletionUtc { get; set; }
    }
}
