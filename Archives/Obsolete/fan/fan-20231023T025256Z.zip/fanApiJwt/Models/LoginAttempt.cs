﻿using System.ComponentModel.DataAnnotations;

namespace fanApiJwt
{
    public class LoginAttempt
    {
        [Key]
        public required Guid Id { get; set; }

        public required string UserName { get; set; }

        public required DateTime AttemptUtc { get; set; }

        public required bool IsSuccessful { get; set; }

        public string? IpAddress { get; set; }

        public string? UserAgent { get; set; }

        public string? Referrer { get; set; }
    }
}
