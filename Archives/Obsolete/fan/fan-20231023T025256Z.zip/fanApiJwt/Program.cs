﻿using System.Text;
using Amazon.SimpleEmail;
using Amazon.SimpleNotificationService;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Serilog;

namespace fanApiJwt
{
    public class Program
    {
        public static void Main (string [] args)
        {
            var xBuilder = WebApplication.CreateBuilder (args);

            // xBuilder.Configuration.SetBasePath (xBuilder.Environment.ContentRootPath);

            Log.Logger = new LoggerConfiguration ().ReadFrom.Configuration (xBuilder.Configuration).CreateLogger ();
            xBuilder.Host.UseSerilog ();

            xBuilder.Services.AddDbContext <ApplicationDbContext> (options => options.UseSqlite (xBuilder.Configuration.GetConnectionString ("DefaultConnection")));

            xBuilder.Services.AddDefaultIdentity <ApplicationUser> (options =>
            {
                // options.Lockout.AllowedForNewUsers ← true
                // options.Lockout.DefaultLockoutTimeSpan ← 5分
                // options.Lockout.MaxFailedAccessAttempts ← 5回

                // RequireConfirmedAccount in ASP.NET Core Identity - Stack Overflow
                // https://stackoverflow.com/questions/71141556/requireconfirmedaccount-in-asp-net-core-identity

                // options.SignIn.RequireConfirmedAccount ← false
                options.SignIn.RequireConfirmedEmail = true;
                options.SignIn.RequireConfirmedPhoneNumber = true;

                options.User.RequireUniqueEmail = true;
            }).
            AddEntityFrameworkStores <ApplicationDbContext> ().
            AddDefaultTokenProviders ();

            xBuilder.Services.AddAuthentication ().AddJwtBearer (x =>
            {
                x.RequireHttpsMetadata = false; // 開発時のみ
                // x.SaveToken ← false

                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidIssuer = xBuilder.Configuration ["Jwt:Issuer"],

                    ValidateAudience = true,
                    ValidAudience = xBuilder.Configuration ["Jwt:Audience"],

                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey (Encoding.ASCII.GetBytes (xBuilder.Configuration ["Jwt:Key"]!))
                };
            });

            xBuilder.Services.AddScoped <UserManager <ApplicationUser>> ();
            xBuilder.Services.AddScoped <SignInManager <ApplicationUser>> ();

            xBuilder.Services.AddControllers ();
            xBuilder.Services.AddEndpointsApiExplorer ();
            xBuilder.Services.AddSwaggerGen ();

            xBuilder.Services.AddAWSService <IAmazonSimpleEmailService> ();
            xBuilder.Services.AddTransient <AmazonSimpleEmailServiceWrapper> ();

            xBuilder.Services.AddAWSService <IAmazonSimpleNotificationService> ();
            xBuilder.Services.AddTransient <AmazonSimpleNotificationServiceWrapper> ();

            var xApp = xBuilder.Build ();

            if (xApp.Environment.IsDevelopment ())
            {
                xApp.UseSwagger ();
                xApp.UseSwaggerUI ();
            }

            xApp.UseAuthorization ();

            xApp.MapControllers ();

            xApp.Run ();
        }
    }
}
