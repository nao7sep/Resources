﻿using Amazon.SimpleEmail.Model;
using Amazon.SimpleEmail;
using System.Text;

namespace fanApiJwt
{
    public class AmazonSimpleEmailServiceWrapper
    {
        private readonly IAmazonSimpleEmailService mAmazonSimpleEmailService;

        public AmazonSimpleEmailServiceWrapper (IAmazonSimpleEmailService amazonSimpleEmailService)
        {
            mAmazonSimpleEmailService = amazonSimpleEmailService;
        }

        public async Task <SendEmailResponse> SendEmailAsync (string senderAddress,
            IEnumerable <string> toAddresses, IEnumerable <string> ccAddresses, IEnumerable <string> bccAddresses,
            string subject, string htmlBody, string textBody)
        {
            return await mAmazonSimpleEmailService.SendEmailAsync (new SendEmailRequest
            {
                Source = senderAddress,

                Destination = new Destination
                {
                    ToAddresses = toAddresses.ToList (),
                    CcAddresses = ccAddresses.ToList (),
                    BccAddresses = bccAddresses.ToList ()
                },

                Message = new Message
                {
                    Body = new Body
                    {
                        Html = new Content
                        {
                            Charset = Encoding.UTF8.BodyName,
                            Data = htmlBody
                        },

                        Text = new Content
                        {
                            Charset = Encoding.UTF8.BodyName,
                            Data = textBody
                        }
                    },

                    Subject = new Content
                    {
                        Charset = Encoding.UTF8.HeaderName,
                        Data = subject
                    }
                },
            });
        }
    }
}
