﻿using Amazon.SimpleNotificationService;
using Amazon.SimpleNotificationService.Model;

namespace fanApiJwt
{
    public class AmazonSimpleNotificationServiceWrapper
    {
        private readonly IAmazonSimpleNotificationService mAmazonSimpleNotificationService;

        public AmazonSimpleNotificationServiceWrapper (IAmazonSimpleNotificationService amazonSimpleNotificationService)
        {
            mAmazonSimpleNotificationService = amazonSimpleNotificationService;
        }

        public async Task <PublishResponse> PublishAsync (string phoneNumber, string message)
        {
            return await mAmazonSimpleNotificationService.PublishAsync (new PublishRequest
            {
                PhoneNumber = phoneNumber,
                Message = message
            });
        }
    }
}
