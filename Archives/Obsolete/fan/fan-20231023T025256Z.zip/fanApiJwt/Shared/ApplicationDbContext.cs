﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace fanApiJwt
{
    public class ApplicationDbContext: IdentityDbContext <ApplicationUser>
    {
        public DbSet <ApplicationUser> ApplicationUsers { get; set; }

        public DbSet <LoginAttempt> LoginAttempts { get; set; }

        public ApplicationDbContext (DbContextOptions <ApplicationDbContext> options):
            base (options)
        {
        }

        protected override void OnModelCreating (ModelBuilder builder)
        {
            base.OnModelCreating (builder);

            builder.Entity <ApplicationUser> (x =>
            {
                x.Property (x => x.CreationUtc).
                    IsRequired ();

                x.Property (x => x.IsActive).
                    IsRequired ();

                x.Property (x => x.IsDeleted).
                    IsRequired ();
            });

            builder.Entity <LoginAttempt> (x =>
            {
                x.Property (x => x.Id).
                    IsRequired ();

                x.Property (x => x.UserName).
                    IsRequired ();

                x.Property (x => x.AttemptUtc).
                    IsRequired ();

                x.Property (x => x.IsSuccessful).
                    IsRequired ();
            });
        }
    }
}
