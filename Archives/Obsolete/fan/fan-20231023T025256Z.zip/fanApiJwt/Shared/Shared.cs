﻿namespace fanApiJwt
{
    public static class Shared
    {
        public static string? GetStringOrNull (string? value)
        {
            return string.IsNullOrWhiteSpace (value) == false ? value : null;
        }
    }
}
