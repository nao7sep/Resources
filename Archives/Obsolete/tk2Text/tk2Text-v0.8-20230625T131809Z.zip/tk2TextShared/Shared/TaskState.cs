﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tk2Text
{
    public enum TaskState
    {
        Later,
        Soon,
        Now,
        Done,
        Cancelled
    }
}
