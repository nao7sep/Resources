﻿using System.ComponentModel;

namespace _fileOrganizer
{
    public class File: INotifyPropertyChanged
    {
        public string? Path { get; set; }

        private string? _newName;

        public string? NewName
        {
            get
            {
                if (_newName != null)
                    return _newName;

                return System.IO.Path.GetFileName (Path);
            }

            set
            {
                if (string.Equals (_newName, value, StringComparison.Ordinal) == false)
                {
                    _newName = value;
                    OnPropertyChanged (nameof (NewName));
                    OnPropertyChanged (nameof (CanCreate));
                }
            }
        }

        private string? _newDirectoryPath;

        public string? NewDirectoryPath
        {
            get => _newDirectoryPath;

            set
            {
                if (string.Equals (_newDirectoryPath, value, StringComparison.Ordinal) == false)
                {
                    _newDirectoryPath = value;
                    OnPropertyChanged (nameof (NewDirectoryPath));
                    OnPropertyChanged (nameof (CanCreate));
                }
            }
        }

        public bool CanCreate
        {
            get
            {
                if (NewDirectoryPath == null)
                    return false;

                string xNewPath = System.IO.Path.Join (NewDirectoryPath, NewName);
                return System.IO.Directory.Exists (xNewPath) == false && System.IO.File.Exists (xNewPath) == false;
            }
        }

        public override string? ToString ()
        {
            string? xName = System.IO.Path.GetFileName (Path);

            if (string.Equals (xName, NewName, StringComparison.Ordinal) == false)
                return $"{xName} => {NewName}";

            return xName;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged (string propertyName) => PropertyChanged?.Invoke (this, new PropertyChangedEventArgs (propertyName));
    }
}
