﻿using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using yyLib;

namespace _fileOrganizer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow: Window
    {
        public MainWindow ()
        {
            try
            {
                InitializeComponent ();

                if (System.IO.File.Exists (Utility.DestinationsFilePath))
                {
                    string xJsonString = System.IO.File.ReadAllText (Utility.DestinationsFilePath, Encoding.UTF8);
                    DataContext = JsonSerializer.Deserialize <MainWindowViewModel> (xJsonString, yyJson.DefaultDeserializationOptions);
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void _Save ()
        {
            var xViewModel = (MainWindowViewModel) DataContext;
            string xJsonString = JsonSerializer.Serialize (xViewModel, yyJson.DefaultSerializationOptions);
            System.IO.File.WriteAllText (Utility.DestinationsFilePath, xJsonString, Encoding.UTF8);

            Directory.CreateDirectory (Utility.BackupsDirectoryPath);
            string xBackupFilePath = Path.Join (Utility.BackupsDirectoryPath, $"Destinations-{DateTime.UtcNow:yyyyMMdd'T'HHmmss'Z'}.json");
            System.IO.File.WriteAllText (xBackupFilePath, xJsonString, Encoding.UTF8);
        }

        private void GroupsListBoxKeyDown (object sender, System.Windows.Input.KeyEventArgs e)
        {
            try
            {
                if (e.Key == System.Windows.Input.Key.Delete)
                {
                    var xViewModel = (MainWindowViewModel) DataContext;

                    if (xViewModel.SelectedGroup != null)
                        DeleteGroupButtonClick (sender, e);
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void CreateGroupButtonClick (object sender, RoutedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;

                CreateWindow xCreateWindow = new ();
                var xCreateWindowViewModel = Utility.InitializeWindow <CreateWindowViewModel> (xCreateWindow, this, "Create Group", "Enter the name of the group.");
                xCreateWindowViewModel.ExistingNames = xViewModel.Groups?.Select (x => x.Name);
                xCreateWindow.ShowDialog ();

                if (xCreateWindowViewModel.IsCreated == true)
                {
                    var xGroup = new Group { Name = xCreateWindowViewModel.Name };

                    xViewModel.Groups ??= [];
                    Utility.InsertItemInOrder (xViewModel.Groups, xGroup, x => x.Name);
                    _Save ();

                    GroupsListBox.SelectedItem = xGroup;
                    GroupsListBox.ScrollIntoView (xGroup);
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void RenameGroupButtonClick (object sender, RoutedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;

                RenameWindow xRenameWindow = new ();
                var xRenameWindowViewModel = Utility.InitializeWindow <RenameWindowViewModel> (xRenameWindow, this, "Rename Group", "Enter the new name of the group.");
                xRenameWindowViewModel.ExistingNames = xViewModel.Groups!.Select (x => x.Name);
                xRenameWindowViewModel.CurrentName = xViewModel.SelectedGroup!.Name;
                xRenameWindow.ShowDialog ();

                if (xRenameWindowViewModel.IsRenamed == true)
                {
                    // IsRenamed will be true if the Rename button is clicked regardless of whether the new name is the same as the current one.
                    // Comparison must be case-sensitive because the user may wish to change the case of the name.

                    if (xRenameWindowViewModel.NewName!.Equals (xRenameWindowViewModel.CurrentName, StringComparison.Ordinal))
                    {
                    #if DEBUG
                        System.Windows.MessageBox.Show (this, "New name is the same as the current one.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                    #endif

                        return;
                    }

                    var xGroup = xViewModel.SelectedGroup;
                    xGroup!.Name = xRenameWindowViewModel.NewName;
                    xViewModel.Groups!.Remove (xGroup);
                    Utility.InsertItemInOrder (xViewModel.Groups, xGroup, x => x.Name);
                    _Save ();

                    GroupsListBox.SelectedItem = xGroup;
                    GroupsListBox.ScrollIntoView (xGroup);
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void DeleteGroupButtonClick (object sender, RoutedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;
                string xMessage = $"Are you sure you want to delete the group '{xViewModel.SelectedGroup!.Name}'?";

                if (System.Windows.MessageBox.Show (this, xMessage, "Delete Group", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
                {
                    var xGroup = xViewModel.SelectedGroup;
                    var xAdjacentGroup = Utility.GetAdjacentItem (xViewModel.Groups!, xGroup);
                    xViewModel.Groups!.Remove (xGroup);
                    _Save ();

                    if (xAdjacentGroup != null)
                    {
                        GroupsListBox.SelectedItem = xAdjacentGroup;
                        GroupsListBox.ScrollIntoView (xAdjacentGroup);
                    }
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void DestinationsListBoxKeyDown (object sender, System.Windows.Input.KeyEventArgs e)
        {
            try
            {
                if (e.Key == System.Windows.Input.Key.Delete)
                {
                    var xViewModel = (MainWindowViewModel) DataContext;

                    if (xViewModel.SelectedDestination != null)
                        RemoveDestinationButtonClick (sender, e);
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void DestinationsListBoxSelectionChanged (object sender, SelectionChangedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;

                if (xViewModel.SelectedDestination != null)
                {
                    if (Directory.Exists (xViewModel.SelectedDestination.Path) == false)
                        System.Windows.MessageBox.Show (this, "Destination does not exist.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                    else
                    {
                        xViewModel.SelectedDestinationSubdirectories = new (
                            Directory.GetDirectories (xViewModel.SelectedDestination.Path, "*", SearchOption.TopDirectoryOnly).
                                Where (x => (System.IO.File.GetAttributes (x) & (FileAttributes.Hidden | FileAttributes.System)) == 0).
                                Order (StringComparer.OrdinalIgnoreCase).
                                Select (y => new Subdirectory { Path = y }));
                    }
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void AddDestinationButtonClick (object sender, RoutedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;

                using FolderBrowserDialog xDialog = new ();
                // xDialog.Description = "Select the destination directory."; // Doesnt look good.
                xDialog.ShowNewFolderButton = true;
                var xResult = xDialog.ShowDialog ();

                if (xResult == System.Windows.Forms.DialogResult.OK && Directory.Exists (xDialog.SelectedPath))
                {
                    if (xViewModel.SelectedGroupDestinations != null &&
                        xViewModel.SelectedGroupDestinations.Any (x => string.Equals (x.Path, xDialog.SelectedPath, StringComparison.OrdinalIgnoreCase)))
                    {
                        System.Windows.MessageBox.Show (this, "Destination already exists.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    var xDestination = new Destination { Path = xDialog.SelectedPath };

                    xViewModel.SelectedGroupDestinations ??= [];
                    Utility.InsertItemInOrder (xViewModel.SelectedGroupDestinations, xDestination, x => x.Path);
                    _Save ();

                    DestinationsListBox.SelectedItem = xDestination;
                    DestinationsListBox.ScrollIntoView (xDestination);
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void RemoveDestinationButtonClick (object sender, RoutedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;
                string xMessage = $"Are you sure you want to delete the destination '{xViewModel.SelectedDestination!.Path}'?";

                if (System.Windows.MessageBox.Show (this, xMessage, "Delete Destination", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
                {
                    var xDestination = xViewModel.SelectedDestination;
                    var xAdjacentDestination = Utility.GetAdjacentItem (xViewModel.SelectedGroupDestinations!, xDestination);
                    xViewModel.SelectedGroupDestinations!.Remove (xDestination);
                    _Save ();

                    if (xAdjacentDestination != null)
                    {
                        DestinationsListBox.SelectedItem = xAdjacentDestination;
                        DestinationsListBox.ScrollIntoView (xAdjacentDestination);
                    }
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void SubdirectoriesListBoxKeyDown (object sender, System.Windows.Input.KeyEventArgs e)
        {
            try
            {
                if (e.Key == System.Windows.Input.Key.Delete)
                {
                    var xViewModel = (MainWindowViewModel) DataContext;

                    if (xViewModel.SelectedSubdirectory != null)
                        DeleteSubdirectoryButtonClick (sender, e);
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void CreateSubdirectoryButtonClick (object sender, RoutedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;

                CreateWindow xCreateWindow = new ();
                var xCreateWindowViewModel = Utility.InitializeWindow <CreateWindowViewModel> (xCreateWindow, this, "Create Subdirectory", "Enter the name of the subdirectory.");
                xCreateWindowViewModel.ExistingNames = xViewModel.SelectedDestinationSubdirectories?.Select (x => Path.GetFileName (x.Path));
                xCreateWindow.ShowDialog ();

                if (xCreateWindowViewModel.IsCreated == true)
                {
                    string xNewPath = Path.Join (xViewModel.SelectedDestination!.Path, xCreateWindowViewModel.Name);

                    // If the subdirectory already exists, regardless of whether it is in the list or not, the operation must be aborted.

                    if (Directory.Exists (xNewPath))
                    {
                        System.Windows.MessageBox.Show (this, "Subdirectory already exists.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    var xSubdirectory = new Subdirectory { Path = xNewPath };

                    // File system operations first because they are more likely to fail.
                    Directory.CreateDirectory (xSubdirectory.Path);

                    xViewModel.SelectedDestinationSubdirectories ??= []; // Just in case.
                    Utility.InsertItemInOrder (xViewModel.SelectedDestinationSubdirectories, xSubdirectory, x => x.Path);
                    _Save ();

                    SubdirectoriesListBox.SelectedItem = xSubdirectory;
                    SubdirectoriesListBox.ScrollIntoView (xSubdirectory);
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void RenameSubdirectoryButtonClick (object sender, RoutedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;

                RenameWindow xRenameWindow = new ();
                var xRenameWindowViewModel = Utility.InitializeWindow <RenameWindowViewModel> (xRenameWindow, this, "Rename Subdirectory", "Enter the new name of the subdirectory.");
                xRenameWindowViewModel.ExistingNames = xViewModel.SelectedDestinationSubdirectories!.Select (x => Path.GetFileName (x.Path));
                xRenameWindowViewModel.CurrentName = Path.GetFileName (xViewModel.SelectedSubdirectory!.Path);
                xRenameWindow.ShowDialog ();

                if (xRenameWindowViewModel.IsRenamed == true)
                {
                    // IsRenamed will be true if the Rename button is clicked regardless of whether the new path is the same as the current one.
                    // Comparison must be case-sensitive because the user may wish to change the case of the name.

                    var xSubdirectory = xViewModel.SelectedSubdirectory;
                    string xNewPath = Path.Join (Path.GetDirectoryName (xSubdirectory!.Path), xRenameWindowViewModel.NewName);

                    // If a subdirectory of the same path already exists and is not the selected list item, the operation must be aborted.
                    // This check is done by the dialog-side code beforehand, but the data in ExistingNames may not be up-to-date
                    // if the user has renamed a subdirectory outside the application.

                    if (Directory.Exists (xNewPath))
                    {
                        if (xNewPath.Equals (xSubdirectory.Path, StringComparison.OrdinalIgnoreCase) == false)
                        {
                            System.Windows.MessageBox.Show (this, "Subdirectory already exists.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }
                    }

                    if (xNewPath.Equals (xSubdirectory.Path, StringComparison.Ordinal)) // Case-sensitively identical path.
                    {
                    #if DEBUG
                        System.Windows.MessageBox.Show (this, "New path is the same as the current one.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                    #endif

                        return;
                    }

                    // File system operations first because they are more likely to fail.
                    Directory.Move (xSubdirectory.Path!, xNewPath);

                    xSubdirectory.Path = xNewPath;
                    xViewModel.SelectedDestinationSubdirectories!.Remove (xSubdirectory);
                    Utility.InsertItemInOrder (xViewModel.SelectedDestinationSubdirectories, xSubdirectory, x => x.Path);
                    _Save ();

                    SubdirectoriesListBox.SelectedItem = xSubdirectory;
                    SubdirectoriesListBox.ScrollIntoView (xSubdirectory);
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void DeleteSubdirectoryButtonClick (object sender, RoutedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;
                string xMessage = $"Are you sure you want to delete the subdirectory '{xViewModel.SelectedSubdirectory!.Path}'?";

                if (System.Windows.MessageBox.Show (this, xMessage, "Delete Subdirectory", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
                {
                    var xSubdirectory = xViewModel.SelectedSubdirectory;

                    // File system operations first because they are more likely to fail.
                    // If the subdirectory exists only as the entry in the list and its physical representation has been deleted, it's OK.

                    if (Directory.Exists (xSubdirectory.Path))
                        Directory.Delete (xSubdirectory.Path, recursive: true);

                    var xAdjacentSubdirectory = Utility.GetAdjacentItem (xViewModel.SelectedDestinationSubdirectories!, xSubdirectory);
                    xViewModel.SelectedDestinationSubdirectories!.Remove (xSubdirectory);
                    _Save ();

                    if (xAdjacentSubdirectory != null)
                    {
                        SubdirectoriesListBox.SelectedItem = xAdjacentSubdirectory;
                        SubdirectoriesListBox.ScrollIntoView (xAdjacentSubdirectory);
                    }
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void FilesListBoxKeyDown (object sender, System.Windows.Input.KeyEventArgs e)
        {
            try
            {
                if (e.Key == System.Windows.Input.Key.Delete)
                {
                    var xViewModel = (MainWindowViewModel) DataContext;

                    if (xViewModel.SelectedFile != null)
                        RemoveFileButtonClick (sender, e);
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void AddFilesButtonClick (object sender, RoutedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;

                using OpenFileDialog xDialog = new ();
                xDialog.Multiselect = true;
                // AddExtension, CheckFileExists, CheckPathExists, DereferenceLinks, ValidateNames are true by default.
                var xResult = xDialog.ShowDialog ();

                if (xResult == System.Windows.Forms.DialogResult.OK && xDialog.FileNames.Length > 0)
                {
                    xViewModel.Files ??= [];
                    List <File> xNewFiles = [];

                    foreach (string xFilePath in xDialog.FileNames)
                    {
                        if (xViewModel.Files.Any (x => x.Path!.Equals (xFilePath, StringComparison.OrdinalIgnoreCase)))
                        {
                            System.Windows.MessageBox.Show (this, "File already added.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            continue;
                        }

                        var xFile = new File { Path = xFilePath };
                        Utility.InsertItemInOrder (xViewModel.Files, xFile, x => x.Path);
                        xNewFiles.Add (xFile);
                    }

                    // Files are not serialized.
                    // _Save ();

                    // Select the last added file and scroll to it.
                    // When you paste a large portion of text into a text editor, the last line is usually visible.

                    for (int temp = xViewModel.Files.Count - 1; temp >= 0; temp --)
                    {
                        if (xNewFiles.Contains (xViewModel.Files [temp]))
                        {
                            FilesListBox.SelectedItem = xViewModel.Files [temp];
                            FilesListBox.ScrollIntoView (xViewModel.Files [temp]);
                            break;
                        }
                    }
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void RenameFileButtonClick (object sender, RoutedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;

                RenameWindow xRenameWindow = new ();
                var xRenameWindowViewModel = Utility.InitializeWindow <RenameWindowViewModel> (xRenameWindow, this, "Rename File", "Enter the new name of the file.");
                xRenameWindowViewModel.ExistingNames = xViewModel.Files!.Select (x => x.NewName);
                xRenameWindowViewModel.CurrentName = xViewModel.SelectedFile!.NewName;
                xRenameWindow.ShowDialog ();

                if (xRenameWindowViewModel.IsRenamed == true)
                {
                    // IsRenamed will be true if the Rename button is clicked regardless of whether the new path is the same as the current one.
                    // Comparison must be case-sensitive because the user may wish to change the case of the name.

                    if (xRenameWindowViewModel.NewName!.Equals (xRenameWindowViewModel.CurrentName, StringComparison.Ordinal))
                    {
                    #if DEBUG
                        System.Windows.MessageBox.Show (this, "New name is the same as the current one.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                    #endif

                        return;
                    }

                    var xFile = xViewModel.SelectedFile;
                    xFile.NewName = xRenameWindowViewModel.NewName;
                    xViewModel.Files!.Remove (xFile); // For updating the UI.
                    Utility.InsertItemInOrder (xViewModel.Files, xFile, x => x.Path);
                    // Files are not serialized.
                    // _Save ();

                    FilesListBox.SelectedItem = xFile;
                    FilesListBox.ScrollIntoView (xFile);
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }

        private void RemoveFileButtonClick (object sender, RoutedEventArgs e)
        {
            try
            {
                var xViewModel = (MainWindowViewModel) DataContext;
                string xMessage = $"Are you sure you want to remove the file '{xViewModel.SelectedFile!.Path}'?";

                if (System.Windows.MessageBox.Show (this, xMessage, "Remove File", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
                {
                    var xFile = xViewModel.SelectedFile;
                    var xAdjacentFile = Utility.GetAdjacentItem (xViewModel.Files!, xFile);
                    xViewModel.Files!.Remove (xFile);
                    // Files are not serialized.
                    // _Save ();

                    if (xAdjacentFile != null)
                    {
                        FilesListBox.SelectedItem = xAdjacentFile;
                        FilesListBox.ScrollIntoView (xAdjacentFile);
                    }
                }
            }

            catch (Exception xException)
            {
                Utility.TryHandleException (this, xException);
            }
        }
    }
}
