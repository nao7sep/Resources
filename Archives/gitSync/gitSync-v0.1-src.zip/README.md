# gitSync

gitSync is a cross-platform console application for automated monitoring and safe synchronization of multiple Git repositories. It scans specified directories, analyzes repository status, and enables safe, automated pulling of remote updates.

*Built with modern C# (.NET 9.0) and designed for extensibility and future enhancements.*

## Key Features

- Recursively discovers Git repositories in configured root directories
- Analyzes repository status (untracked, modified, staged, deleted, conflicted files)
- Detects local/remote branch and commit status (unpushed/unpulled commits, stashed changes)
- Identifies repositories that are safe to pull automatically (no uncommitted or stashed changes, no unpushed commits)
- Presents a summary and detailed status reports for all repositories
- Prompts for confirmation before performing pull operations
- Provides colored console output for clarity, including colored error and warning messages
- Runs repository analysis in parallel for performance using thread-safe output
- Cross-platform support: Windows, macOS, Linux
- Supports `NoAutoPullRepositories` configuration to exclude specific repositories from automated pull operations

## Usage

1. Configure root directories, ignore patterns, and (optionally) `NoAutoPullRepositories` in `appsettings.json`.
2. Run gitSync from the console.
3. Review the status summary and follow prompts to safely synchronize repositories.

---
For detailed technical specifications and architecture, see [`specs/gitsync-specifications-v0.1.md`](specs/gitsync-specifications-v0.1.md).