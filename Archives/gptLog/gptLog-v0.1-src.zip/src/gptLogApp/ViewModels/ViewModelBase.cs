using CommunityToolkit.Mvvm.ComponentModel;

namespace gptLogApp.ViewModels
{
    public class ViewModelBase : ObservableObject
    {
    }
}