using System;

namespace gptLogApp.Model
{
    public enum Role
    {
        User,
        Assistant
    }
}