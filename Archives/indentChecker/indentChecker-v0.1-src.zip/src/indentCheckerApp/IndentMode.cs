namespace indentCheckerApp
{
    public enum IndentMode
    {
        Flex,
        Strict
    }
}
