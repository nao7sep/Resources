﻿namespace mediaTime
{
    public enum ResultType
    {
        Success,
        FailedToRename,
        Unchanged // Because the timestamp was already proper.
    }
}
