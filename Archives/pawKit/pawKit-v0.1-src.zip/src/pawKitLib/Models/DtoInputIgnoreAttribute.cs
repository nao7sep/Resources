using System;

namespace pawKitLib.Models;

[AttributeUsage(AttributeTargets.Property)]
public class DtoInputIgnoreAttribute : Attribute
{
}
