﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace srcZip
{
    public enum ParamKind
    {
        Exclude,
        Copy,
        Delete
    }
}
