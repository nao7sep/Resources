﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace taskKiller
{
    public enum iTaskState
    {
        Later,
        Soon,
        Now,
        Done,
        Cancelled
    }
}
