﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tk2Text
{
    internal enum iPageGenerationResult
    {
        Created = 1,
        Updated = 2,
        Unchanged = 3
    }
}
