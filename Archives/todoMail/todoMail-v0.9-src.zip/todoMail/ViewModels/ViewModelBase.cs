﻿using ReactiveUI;

namespace todoMail.ViewModels;

public class ViewModelBase: ReactiveObject
{
}
