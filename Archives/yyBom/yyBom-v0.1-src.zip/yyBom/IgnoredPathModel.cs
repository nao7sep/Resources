﻿namespace yyBom
{
    public class IgnoredPathModel
    {
        public PathType? PathType { get; set; }

        public string? Path { get; set; }
    }
}
