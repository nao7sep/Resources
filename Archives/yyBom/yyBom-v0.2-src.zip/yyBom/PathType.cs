﻿namespace yyBom
{
    public enum PathType
    {
        DirectoryPath,
        DirectoryName,
        FilePath,
        FileName,
        FileExtension
    }
}
