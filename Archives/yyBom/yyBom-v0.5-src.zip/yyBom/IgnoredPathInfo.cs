﻿namespace yyBom
{
    public class IgnoredPathInfo
    {
        public PathType? PathType { get; set; }

        public string? Path { get; set; }
    }
}
