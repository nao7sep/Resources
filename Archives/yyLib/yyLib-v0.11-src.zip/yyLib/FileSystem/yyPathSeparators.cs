﻿namespace yyLib
{
    public static class yyPathSeparators
    {
        public static char Nt => '\\';

        public static char Posix => '/';
    }
}
