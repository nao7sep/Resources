﻿namespace yyLib
{
    public enum yyGptChatRole
    {
        Developer,
        System,
        User,
        Assistant,
        Tool,
        Function
    }
}
