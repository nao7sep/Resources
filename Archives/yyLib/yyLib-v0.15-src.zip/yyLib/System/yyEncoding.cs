﻿using System.Text;

namespace yyLib
{
    public static class yyEncoding
    {
        public static readonly Encoding Default = Encoding.UTF8;
    }
}
