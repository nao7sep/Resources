﻿namespace yyLib
{
    public static class yyString
    {
        public static readonly string DefaultNewLine = Environment.NewLine;

        public static readonly string DefaultSingleIndent = "    ";
    }
}
