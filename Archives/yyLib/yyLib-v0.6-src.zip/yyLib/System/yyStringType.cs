﻿namespace yyLib
{
    public enum yyStringType
    {
        Null,
        Empty,
        WhiteSpace, // All WhiteSpace.
        Visible // At least one char is visible.
    }
}
