﻿namespace yyLib
{
    public static class yyPathSeparator
    {
        public static char Nt => '\\';

        public static char Posix => '/';
    }
}
