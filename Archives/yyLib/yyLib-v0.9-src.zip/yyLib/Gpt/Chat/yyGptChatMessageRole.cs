﻿namespace yyLib
{
    public enum yyGptChatMessageRole
    {
        System,
        User,
        Assistant
    }
}
