﻿# yyMail

The following documents are updated from time to time, so please view the latest version on the internet.

* [About this Project](https://github.com/nao7sep/Resources/blob/main/Documents/Projects/yyMail/yyMail.md)
* [About the Developer](https://github.com/nao7sep/Resources/blob/main/Documents/General/About%20the%20Developer/About%20the%20Developer.md)
* [Request for Cooperation](https://github.com/nao7sep/Resources/blob/main/Documents/General/Request%20for%20Cooperation/Request%20for%20Cooperation.md)

以下のドキュメントは随時更新されますので、インターネット上の最新版をご覧ください。

* [このプロジェクトについて](https://github.com/nao7sep/Resources/blob/main/Documents/Projects/yyMail/yyMail.ja.md)
* [開発者について](https://github.com/nao7sep/Resources/blob/main/Documents/General/About%20the%20Developer/About%20the%20Developer.ja.md)
* [ご協力のお願い](https://github.com/nao7sep/Resources/blob/main/Documents/General/Request%20for%20Cooperation/Request%20for%20Cooperation.ja.md)
