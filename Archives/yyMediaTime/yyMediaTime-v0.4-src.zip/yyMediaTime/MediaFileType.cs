﻿namespace yyMediaTime
{
    public enum MediaFileType
    {
        Image,
        Video,
        Unsupported // Unsupported media files and files that are not media files.
    }
}
