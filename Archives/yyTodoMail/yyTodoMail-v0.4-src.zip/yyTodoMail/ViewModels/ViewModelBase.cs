﻿using ReactiveUI;

namespace yyTodoMail.ViewModels;

public class ViewModelBase: ReactiveObject
{
}
